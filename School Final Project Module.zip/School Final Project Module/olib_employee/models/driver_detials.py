# -*- coding: utf-8 -*-

from odoo import api, fields, models, tools


class OLIBDriverDetails(models.Model):
    _name = 'driver.details'

    _rec_name ="display_name"

    @api.depends('driver_lastname','driver_firstname')
    def _compute_display_name(self):
        for record in self:
            record.display_name = '%s %s' %(record.driver_lastname, record.driver_firstname)

    image = fields.Binary(string="Image", attachment=True)
    id_number = fields.Char(string="ID Number")
    driver_lastname = fields.Char(string="Last Name", required=True)
    driver_firstname = fields.Char(string="First Name", required=True)
    driver_email = fields.Char(string="Work Email")
    licence_number = fields.Char(string="Licence Number")
    licence_type = fields.Selection([('a','A-Oridinary'), ('b','B-Chauffeur'),('c','C-Heavy Duty')], string="Licence Type")
    licence_date_issues = fields.Date(string="Licence Date Issues")
    licence_date_expires = fields.Date(string="Licence Date Expires")
    driver_number = fields.Char(string="Work Phone", required=True)
    display_name = fields.Char(string='Driver Name', compute='_compute_display_name')  