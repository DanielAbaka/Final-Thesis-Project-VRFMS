# -*- coding: utf-8 -*-

from odoo import api, fields, models, tools


class ManagerActions(models.Model):
    _name = 'manager.actions'

    _rec_name ="display_name"

    @api.depends('manager_lastname','manager_firstname')
    def _compute_display_name(self):
        for record in self:
            record.display_name = '%s %s' %(record.manager_lastname, record.manager_firstname)

    image = fields.Binary(string="Image", attachment=True)
    id_number = fields.Char(string="ID Number")
    manager_lastname = fields.Char(string="Last Name", required=True)
    manager_firstname = fields.Char(string="First Name", required=True)
    manager_email = fields.Char(string="Work Email")
    manager_number = fields.Char(string="Work Phone", required=True)
    display_name = fields.Char(string='Employee Name', compute='_compute_display_name')
 

class TransportActions(models.Model):
    _name = 'transport.actions'

    _rec_name ="display_name"

    @api.depends('transport_lastname','transport_firstname')
    def _compute_display_name(self):
        for record in self:
            record.display_name = '%s %s' %(record.transport_lastname, record.transport_firstname)


    image = fields.Binary(string="Image", attachment=True)
    id_number = fields.Char(string="ID Number")
    transport_lastname = fields.Char(string="Last Name", required=True)
    transport_firstname = fields.Char(string="First Name", required=True)
    transport_email = fields.Char(string="Work Email")
    transport_number = fields.Char(string="Work Phone", required=True)
    display_name = fields.Char(string='Employee Name', compute='_compute_display_name')
 


class SecurityActions(models.Model):
    _name = 'security.actions'

    _rec_name ="display_name"

    @api.depends('security_lastname','security_firstname')
    def _compute_display_name(self):
        for record in self:
            record.display_name = '%s %s' %(record.security_lastname, record.security_firstname)


    image = fields.Binary(string="Image", attachment=True)
    id_number = fields.Char(string="ID Number")
    security_lastname = fields.Char(string="Last Name", required=True)
    security_firstname = fields.Char(string="First Name", required=True)
    security_email = fields.Char(string="Work Email")
    security_number = fields.Char(string="Work Phone", required=True)
    display_name = fields.Char(string='Employee Name', compute='_compute_display_name')
 