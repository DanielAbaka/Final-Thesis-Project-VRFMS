# -*- coding: utf-8 -*-

from odoo import api, fields, models, tools


class EmployeeStatus(models.Model):
    _name = 'employee.status'

    _rec_name = 'employee_status'

    employee_status = fields.Char(string="Employee Status", required=True) 

class EmployeePosition(models.Model):
    _name = 'employee.position'

    _rec_name = 'employee_position'

    employee_position = fields.Char(string="Employee Position", required=True)

class EmployeePosition(models.Model):
    _name = 'employee.department'

    _rec_name = 'employee_department'

    employee_department = fields.Char(string="Employee Department", required=True)
    
class EmployeeLevel(models.Model):
    _name = 'employee.level'

    _rec_name = 'employee_level'


    employee_level = fields.Char(string="Employee Level", required=True)