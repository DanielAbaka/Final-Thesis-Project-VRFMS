# -*- coding: utf-8 -*-

from odoo import api, fields, models, tools


class OLIBEmployeeDetails(models.Model):
    _name = 'employee.details'

    _rec_name ="display_name"

    @api.depends('employee_lastname','employee_firstname')
    def _compute_display_name(self):
        for record in self:
            record.display_name = '%s %s' %(record.employee_lastname, record.employee_firstname)

    image = fields.Binary(string="Image", attachment=True)
    id_number = fields.Char(string="ID Number")
    employee_lastname = fields.Char(string="Last Name", required=True)
    employee_firstname = fields.Char(string="First Name", required=True)
    department = fields.Many2one('employee.department', string="Department")
    position = fields.Many2one('employee.position', string="Position")
    status = fields.Many2one('employee.status', string="Employee Status")
    level = fields.Many2one('employee.level', string="Employee Level")
    employee_email = fields.Char(string="Work Email")
    employee_number = fields.Char(string="Work Phone", required=True)
    display_name = fields.Char(string='Employee Name', compute='_compute_display_name')  