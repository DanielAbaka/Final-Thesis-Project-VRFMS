# -*- coding: utf-8 -*-
{
    'name': 'OLIB REQUESTS',
    'summary': """This module will enable employees to request for vehicles""",
    'version': '11.0.0.0.0',
    'description': """This module will enable employees to request for vehicle""",
    'author': 'Daniel Abaka',
    'company': 'Orange Liberia',
    'website': 'http://www.orange.com',
    'category': 'Tools',
    'depends': ['base','olib_vehicle','olib_employee'],
    'license': 'AGPL-3',
    'data': [

        
        'views/vehicle_request_views.xml',
        'views/vehicle_request_report_views.xml',
        'views/vehicle_direct_check_views.xml',
        'views/vehicle_direct_check_report_views.xml',
       
       
    ],
    'demo': [],
    'installable': True,
    'auto_install': False,
    'application': True,
}
