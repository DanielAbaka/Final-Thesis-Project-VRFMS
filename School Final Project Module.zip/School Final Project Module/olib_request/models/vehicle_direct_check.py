# -*- coding: utf-8 -*-
import requests
from datetime import datetime
from odoo import models, fields, api
from odoo.exceptions import Warning
from odoo import api, fields, models, tools


class OLIBVehicleDirectCheckDetails(models.Model):
    _name = 'direct.vehicle.check'

    @api.model
    def create(self, vals):
        vals['name'] = self.env['ir.sequence'].next_by_code('direct.vehicle.check')
        return super(OLIBVehicleDirectCheckDetails, self).create(vals)


    state = fields.Selection([('new', 'NEW'), ('out', 'CHECK-OUT'),('in', 'CHECK-IN')], default='new')
    name = fields.Char(string='Check Number', copy=False)
    drive_out_by = fields.Selection([('emp', 'Employee'), ('dr', 'Driver')],default='dr', string='Drive Out By', required=True)
    employee_out_name = fields.Many2one('employee.details', string="Employee Name")
    driver_out_name = fields.Many2one('driver.details', string="Driver")
    driver_out_number = fields.Char(related='driver_out_name.driver_number', string="Mobile", readonly=True)
    employee_out_number = fields.Char(related='employee_out_name.employee_number', string="Mobile", readonly=True)
    department = fields.Many2one('employee.department', string='Department')
    seating_capacity = fields.Char(string="Number Of  Persons", required=True)
    location = fields.Char(string='Start From', required=True)
    destination = fields.Char(string='Destination', required=True)
    reason = fields.Text(string='Reason', required=True)
    transport_assign_name = fields.Many2one('transport.actions',string='Transport Assign')
    transport_assign_number = fields.Char(related='transport_assign_name.transport_number', string='Mobile Number', readonly=True)
    license_plate = fields.Many2one('vehicle.details', string="Plate Number", required=True)
    vehicles_type = fields.Many2one('vehicle.details.types' ,string="Vehicle Type", required=True)
    check_out_date_time = fields.Datetime(string="Check Out Time",default=lambda *a: datetime.now(), readonly=True)
    start_fuel_reading = fields.Selection([('5', 'Full Tank'), ('4', '3.4 Quater Tank'), ('3', 'Half Tank'), ('2', '1.2 Quater Tank'), ('1', 'Less 1.2 Quater Tank')], string='Start Fuel Reading', required=True)
    start_mileage = fields.Char(string="Start Mileage", required=True)

    drive_in_by = fields.Selection([('ein', 'Employee'), ('din', 'Driver')],default='', string='Drive In By')
    driver_in_name = fields.Many2one('driver.details', string="Driver Name")
    employee_in_name = fields.Many2one('employee.details', string="Employee Name")
    check_in_date_time = fields.Datetime(string="Check In Time")
    return_fuel_reading = fields.Selection([('6', 'Full Tank'), ('5', '3.4 Quater Tank'), ('4', 'Half Tank'), ('3', '1.2 Quater Tank'), ('2', 'Less 1.2 Quater Tank'),('1', 'Empty Tank')], string='Return Fuel Reading')
    return_mileage = fields.Char(string="End Mileage")


    @api.multi
    def button_check_out(self):
        for record in self:
            record.write({'state': 'out'})


            #vehicle check-out sms starts here
            method_name = 'send_sms'
            sendSMS = getattr(SMS,method_name)

            driver_out_number=record["driver_out_number"]

            employee_out_number=record["employee_out_number"]

            transport_assign_number=record["transport_assign_number"]

            vehicle_out = str(self.license_plate.plate_number)

            destin = str(self.destination)

            time_out = str(self.check_out_date_time)

            sendSMS([transport_assign_number],"Vehicle "+vehicle_out+" Going "+destin+" is CHECKED-OUT at "+time_out)

            if self.drive_out_by=="dr":
                sendSMS([driver_out_number],"You have been CHECKED-OUT successfully, Safe trip....")
            else:
                sendSMS([employee_out_number],"You have been CHECKED-OUT successfully, Safe trip....")
   


class OLIBVehicleDirectCheckInDetails(models.Model):
        _name = "direct.vehicle.check.in"


        drive_in_by = fields.Selection([('din', 'Driver'), ('ein', 'Employee')],default='din', string='Drive In By', required=True)
        driver_in_name = fields.Many2one('driver.details', string="Driver Name")
        employee_in_name = fields.Many2one('employee.details', string="Employee Name")
        check_in_date_time = fields.Datetime(string="Check In Time",default=lambda *a: datetime.now(),readonly=True)
        return_fuel_reading = fields.Selection([('6', 'Full Tank'), ('5', '3.4 Quater Tank'), ('4', 'Half Tank'), ('3', '1.2 Quater Tank'), ('2', 'Less 1.2 Quater Tank'),('1', 'Empty Tank')], string='Return Fuel Reading', required=True)
        return_mileage = fields.Char(string="End Mileage", required=True)

        
        @api.multi
        def button_check_in(self):
            if self.env.context.get('request_id'):
                request = self.env['direct.vehicle.check'].browse(self.env.context.get('request_id'))
                request.write({'state': 'in', 'drive_in_by': self.drive_in_by, 'driver_in_name': self.driver_in_name.id, 'check_in_date_time': self.check_in_date_time, 'employee_in_name': self.employee_in_name.id, 'return_fuel_reading': self.return_fuel_reading, 'return_mileage': self.return_mileage})


                #vehicle check-in sms notification starts here
                method_name = 'send_sms'
                sendSMS = getattr(SMS,method_name)

                drive_out_by="drive_out_by"
                dib = request[drive_out_by]
               

                field="driver_out_number"
                driver_out_number=request[field]

                field="employee_out_number"
                employee_out_number=request[field]
               
                field="transport_assign_number"
                transport_assign_number=request[field]

                field="start_mileage"
                start_mileage=request[field]
                if start_mileage>self.return_mileage:
                        raise Warning('End Mileage must be greater than Start Mileage: '+ start_mileage)

                vehicles_type="license_plate"
                vehicle_in=request[vehicles_type].plate_number
                destination="destination"
                destin=request[destination] 

                time_in = str(self.check_in_date_time)


                if dib=="din":
                    sendSMS([driver_out_number],"You have been CHECKED-IN successfully, Welcome Back...")
                    sendSMS([transport_assign_number],"Vehicle "+vehicle_in+" From "+destin+" is CHECKED-IN at "+time_in)
                else:
                    sendSMS([employee_out_number],"You have been CHECKED-IN successfully, Welcome Back...")
                    sendSMS([transport_assign_number],"Vehicle "+vehicle_in+" From "+destin+" is CHECKED-IN at "+time_in)
                





class SMS(models.Model):
    _name = "sms"

    @api.multi
    def send_sms(employee_numbers, message_content):
        #_logger.info("Ping -c 1 192.168.15.21")
        # ping = os.system("ping  192.168.15.21")
        #_logger.info(ping)
        for recipient_number in employee_numbers:
            url="http://192.168.15.21:8091/CellcomAPIService"
            headers = {'content-type': 'application/soap+xml'}
            body ="\
            <s:Envelope xmlns:a='http://www.w3.org/2005/08/addressing' xmlns:s='http://www.w3.org/2003/05/soap-envelope'>\
              <s:Header>\
                <a:Action s:mustUnderstand='1'>http://tempuri.org/ISubscribers/SubscriberSendNotification</a:Action>\
                <a:MessageID>urn:uuid:3472a125-74f5-4914-865d-d1037d1dcbd8</a:MessageID>\
                <a:ReplyTo>\
                  <a:Address>http://www.w3.org/2005/08/addressing/anonymous</a:Address>\
                </a:ReplyTo>\
              </s:Header>\
              <s:Body>\
                <SubscriberSendNotification xmlns='http://tempuri.org/'>\
                  <c_subs_req xmlns:d4p1='http://schemas.datacontract.org/2004/07/CellcomAPILibrary' xmlns:i='http://www.w3.org/2001/XMLSchema-instance'>\
                    <d4p1:Client>wcf client tool</d4p1:Client>\
                    <d4p1:Password>h1$d/6Hf78(hg</d4p1:Password>\
                    <d4p1:UserName>HIS</d4p1:UserName>\
                    <d4p1:DestinationNumber>%s</d4p1:DestinationNumber>\
                    <d4p1:NotificationText>%s</d4p1:NotificationText>\
                    <d4p1:NotificationType>SMS</d4p1:NotificationType>\
                    <d4p1:OriginatingNumber>OLIB VRFMS</d4p1:OriginatingNumber>\
                  </c_subs_req>\
                </SubscriberSendNotification>\
              </s:Body>\
            </s:Envelope>\
            " %(recipient_number, message_content)
            response = requests.post(url,data=body,headers=headers)
            print(response.content)

            return response

        return False
