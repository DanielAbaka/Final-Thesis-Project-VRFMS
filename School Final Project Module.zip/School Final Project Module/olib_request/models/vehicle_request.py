# -*- coding: utf-8 -*-
import requests
from datetime import datetime
from odoo import models, fields, api
from odoo.exceptions import Warning
from odoo import api, fields, models, tools


class OLIBVehicleRequestDetails(models.Model):
    _name = 'vehicle.request.details'

    @api.model
    def create(self, vals):
        vals['name'] = self.env['ir.sequence'].next_by_code('vehicle.request.details')
        return super(OLIBVehicleRequestDetails, self).create(vals)

    state = fields.Selection([('new', 'NEW'),('manager', 'MANAGER'), ('wap', 'TRANSPORT DEPT'),('sec', 'SECURITY'),
                                ('out', 'CHECK-OUT'),('checkin', 'CHECK-IN'), ('ret', 'REFUSED')], default='new')
    name = fields.Char(string='Request Number', copy=False)
    emp_request_name = fields.Many2one('employee.details',string='Requester Name',required=True)
    emp_request_number = fields.Char(related='emp_request_name.employee_number',string='Mobile',readonly=True)
    department = fields.Many2one('employee.department', string='Department')
    position = fields.Many2one('employee.position', string='Position')
    vehicle_type = fields.Selection([('PickUp(4X4)', 'PickUp(4X4)'), ('Jeep', 'Jeep'), ('Sedan', 'Sedan'), ('Truck', 'Truck'),
                                        ('Forklit', 'ForkLit'),('Station Wagon', 'Station Wagon'),('MINI BUS (15 Seated)', 
                                            'MINI BUS (15 Seated)'),('BIG BUS (32 Seated)', 'BIG BUS (32 Seated)'),
                                        ('Availiable Car', 'Availiable Car')], string=' Type Of Vehicle', required=True)
    location = fields.Char(string='Start From', required=True)
    destination = fields.Char(string='Destination', required=True)
    seating_capacity = fields.Char(string="Number Of  Persons", required=True)
    drive_out_by = fields.Selection([('em', 'Employee'), ('dr', 'Driver')],default='dr', string='Drive Out By', required=True)
    employee_out_name = fields.Many2one('employee.details', string="Employee Name")
    req_date_time = fields.Datetime(string='Requested Time', default=lambda *a: datetime.now(),readonly=True)
    reasons = fields.Text(string='Reason', required=True)
    manager_approve_name = fields.Many2one('manager.actions',string='Manager', required=True)
    manager_approve_number = fields.Char(related='manager_approve_name.manager_number',string='Mobile', readonly=True)


    opinion = fields.Selection([('AGREE', 'AGREE')],default='AGREE', string='Opinion')
    transport_assign_name = fields.Many2one('transport.actions',string='Transport Assign')
    transport_assign_number = fields.Char(related='transport_assign_name.transport_number', string='Mobile Number', readonly=True)
    approved_date = fields.Datetime(string='Date')
    comment = fields.Text(string="Comment")


    license_plate = fields.Many2one('vehicle.details', string="Plate Number")
    vehicles_type = fields.Many2one('vehicle.details.types' ,string="Vehicle Type")
    driver_assign_name = fields.Many2one('driver.details', string="Driver Name")
    driver_assign_number = fields.Char(related='driver_assign_name.driver_number', string="Driver Number")
    security_check_name = fields.Many2one('security.actions',string='Security Name')
    security_check_number = fields.Char(related='security_check_name.security_number', string='Security Number')


    check_out_date_time = fields.Datetime(string="Check Out Time")
    start_fuel_reading = fields.Selection([('6', 'Full Tank'), ('5', '3.4 Quater Tank'), ('4', 'Half Tank'), 
                                            ('3', '1.2 Quater Tank'), ('2', 'Less 1.2 Quater Tank'),
                                                ('1', 'Empty Tank')], string='Start Fuel Reading')
    start_mileage = fields.Char(string="Start Mileage")
    drive_in_by = fields.Selection([('ein', 'Employee'), ('din', 'Driver')],default='', string='Drive In By')
    driver_in_name = fields.Many2one('driver.details', string="Driver Name")
    employee_in_name = fields.Many2one('employee.details', string="Employee Name")
    check_in_date_time = fields.Datetime(string="Check In Time")
    return_fuel_reading = fields.Selection([('6', 'Full Tank'), ('5', '3.4 Quater Tank'), ('4', 'Half Tank'), 
                                            ('3', '1.2 Quater Tank'), ('2', 'Less 1.2 Quater Tank'),('1', 'Empty Tank')]
                                            , string='Return Fuel Reading')
    return_mileage = fields.Char(string="End Mileage")


    refuse_opinion = fields.Selection([('DISAGREE', 'DISAGREE')],default='DISAGREE', string='Opinion')
    refuse_date =fields.Datetime(string="Refuse Date") 
    refuse_reason =fields.Text(string="Comment")



    @api.multi
    def button_submit(self):
        for record in self:
            record.write({'state': 'manager'})


        #vehicle request sms notification starts here
        method_name = 'send_sms'
        sendSMS = getattr(SMS,method_name)
        emp_request_number=record["emp_request_number"]
        manager_approve_number=record["manager_approve_number"]
        employee = str(self.emp_request_name.employee_lastname)+" "+str(self.emp_request_name.employee_firstname)
        vehicle = str(self.vehicle_type)
        destin = str(self.destination)
        time = str(self.req_date_time)

        #SMS Start
        sendSMS([manager_approve_number],employee+" is requesting for "+vehicle+" going "+destin+" at "+time+" need your Approval thanks. From OLIB-VRFMS")
        
        sendSMS([emp_request_number],"Your request has been sent to your Manager for Approval thanks for using OLIB-VRFMS")





class ManagerRequestApproved(models.Model):
    _name = "manager.approved"

    opinion = fields.Selection([('AGREE', 'AGREE')],default='AGREE', string='Opinion', readonly=True)
    transport_assign_name = fields.Many2one('transport.actions',string='Transport Assign', required=True)
    transport_assign_number = fields.Char(related='transport_assign_name.transport_number', string='Mobile', readonly=True)
    approved_date = fields.Datetime(default=lambda *a: datetime.now(),string='Date', readonly=True)
    comment = fields.Text(string="Comment", required=True)


    @api.multi
    def button_send(self):
        if self.env.context.get('request_id'):
            request = self.env['vehicle.request.details'].browse(self.env.context.get('request_id'))
            request.write({'state': 'wap', 'approved_date': self.approved_date,'opinion': self.opinion,'comment': self.comment, 
                'transport_assign_name': self.transport_assign_name.id, 'transport_assign_number': self.transport_assign_number})


            #vehicle request sms notification starts here
            method_name = 'send_sms'
            sendSMS = getattr(SMS,method_name)
            field="emp_request_number"
            emp_request_number=request[field]
            field="manager_approve_number"
            manager_approve_number=request[field]
            field="transport_assign_number"
            transport_assign_number=request[field]

            vehicle_type="vehicle_type"
            vehicle_req=str(request[vehicle_type])
            destination="destination"
            destins=request[destination]
            req_date_time="req_date_time"
            time_req=request[req_date_time]
            field="emp_request_name"
            emp_request_name=request[field]
            emp_request_name = str(emp_request_name.employee_lastname)+" "+str(emp_request_name.employee_firstname)

            dob = "drive_out_by"
            drive_out_by=request[dob]

            if drive_out_by=="em":
                sendSMS([transport_assign_number],emp_request_name+" is requesting for "+vehicle_req+" going "+destins+" at "+time_req+ " and has been Approved")
            else:
                sendSMS([transport_assign_number],emp_request_name+" is requesting for "+vehicle_req+" and Driver going "+destins+" at "+time_req+ " and has been Approved. From OLIB-VRFMS")
                
                sendSMS([emp_request_number],"Your request has been Approved by your Manager and sent to TRANSPORT SECTION thanks for using OLIB-VRFMS")
                sendSMS([manager_approve_number],"Approved vehicle request has been sent to TRANSPORT SECTION thanks for using OLIB-VRFMS")



class AssignedVehicle(models.Model):
    _name = "assigned.vehicle.request"


    license_plate = fields.Many2one('vehicle.details', string="Select Plate", required=True)
    vehicles_type = fields.Many2one('vehicle.details.types',string="Vehicle Type", required=True)
    driver_assign_name = fields.Many2one('driver.details', string="Driver Name")
    driver_assign_number = fields.Char(related='driver_assign_name.driver_number', string="Driver Number", readonly=True)
    security_check_name = fields.Many2one('security.actions',string='Security Name', required=True)
    security_check_number = fields.Char(related='security_check_name.security_number', string='Security Number', readonly=True)


    @api.multi
    def button_assign(self):
        if self.env.context.get('request_id'):
            request = self.env['vehicle.request.details'].browse(self.env.context.get('request_id'))
            request.write({'state': 'sec', 'license_plate': self.license_plate.id, 'vehicles_type': self.vehicles_type.id, 'driver_assign_name': self.driver_assign_name.id, 'driver_assign_number': self.driver_assign_number, 'security_check_name': self.security_check_name.id,'security_check_number': self.security_check_number})
            

            #vehicle assigned_sms_notification_starts_here
            method_name = 'send_sms'
            sendSMS = getattr(SMS,method_name)
            field="emp_request_number"
            emp_request_number=request[field]
            field="name"
            name=request[field]          
            plate = str(self.license_plate.plate_number)
            driver = str(self.driver_assign_name.driver_lastname)+" "+str(self.driver_assign_name.driver_firstname)
            
            d_number = str(self.driver_assign_number)
            field="driver_assign_number"
            driver_assign_number=request[field]
            
            dob = "drive_out_by"
            drive_out_by=request[dob]

            d_number = str(self.driver_assign_number)
            field="security_check_number"
            security_check_number=request[field]

            field="emp_request_name"
            emp_request_name=request[field]
            emp_request_name = str(emp_request_name.employee_lastname)+" "+str(emp_request_name.employee_firstname)


            if drive_out_by=="dr": #SMS Start
                sendSMS([emp_request_number],"Vehicle "+plate+" with Driver "+driver+" is assigned to you. Please call this number "+d_number+" to start your trip. Thanks for using OLIB-VRFMS.")
                sendSMS([driver_assign_number],"Vehicle "+plate+" with Employee "+emp_request_name+" is assigned to you. Please call this number "+emp_request_number+" to start your trip. Request Number: "+name)
                sendSMS([security_check_number],"Vehicle "+plate+" with Employee "+emp_request_name+" and Driver "+driver+" is going out please CHECK OUT before leaving. Request Number: "+name+", From TRANSPORT SEC.")
            else:
                sendSMS([emp_request_number],"Vehicle "+plate+" is assigned to you. Please pickup the KEY to start your trip. Thanks for using OLIB-VRFMS. Request Number: "+name)
                sendSMS([security_check_number],"Vehicle "+plate+" with Employee "+emp_request_name+" is going out please CHECK OUT using Request Number "+name+" before leaving . From TRANSPORT SEC.")
           


class CheckVehicleOut(models.Model):
    _name = "check.vehicle.out"

    check_out_date_time = fields.Datetime(string="Check Out Time",default=lambda *a: datetime.now(), readonly=True)
    start_fuel_reading = fields.Selection([('5', 'Full Tank'), ('4', '3.4 Quater Tank'), ('3', 'Half Tank'), ('2', '1.2 Quater Tank'), ('1', 'Less 1.2 Quater Tank')], string='Start Fuel Reading', required=True)
    start_mileage = fields.Char(string="Start Mileage", required=True)


    @api.multi
    def button_check_out(self):
        if self.env.context.get('request_id'):
            request = self.env['vehicle.request.details'].browse(self.env.context.get('request_id'))
            request.write({'state': 'out', 'check_out_date_time': self.check_out_date_time, 'start_fuel_reading': self.start_fuel_reading, 'start_mileage': self.start_mileage})


            #driver_sms_function_start_here
            method_name = 'send_sms'
            sendSMS = getattr(SMS,method_name)
            vehicle_type="license_plate"
            vehicle_out=request[vehicle_type].plate_number
            destination="destination"
            destin=request[destination]
            time_out = str(self.check_out_date_time)

            field="transport_assign_number"
            transport_assign_number=request[field]

            field="driver_assign_number"
            driver_assign_number=request[field]

            dob = "drive_out_by"
            drive_out_by=request[dob]

            field="emp_request_number"
            emp_request_number=request[field]

            sendSMS([transport_assign_number],"Vehicle "+vehicle_out+" Going "+destin+" is CHECKED-OUT at "+time_out)

            if drive_out_by=="dr":
                sendSMS([driver_assign_number],"You have been CHECKED-OUT successfully. Safe trip....")
            else:
                sendSMS([emp_request_number],"You have been CHECKED-OUT successfully. Safe trip....")
            

class CheckIn(models.Model):
    _name = "check.vehicle.in"


    drive_in_by = fields.Selection([('ein', 'Employee'), ('din', 'Driver')],default='din', string='Drive In By', required=True)
    driver_in_name = fields.Many2one('driver.details', string="Driver Name")
    employee_in_name = fields.Many2one('employee.details', string="Employee Name")
    check_in_date_time = fields.Datetime(string="Check In Time" ,default=lambda *a: datetime.now(), readonly=True)
    return_fuel_reading = fields.Selection([('6', 'Full Tank'), ('5', '3.4 Quater Tank'), ('4', 'Half Tank'), ('3', '1.2 Quater Tank'), ('2', 'Less 1.2 Quater Tank'),('1', 'Empty Tank')], string='Return Fuel Reading', required=True)
    return_mileage = fields.Char(string="End Mileage", required=True)


    @api.multi
    def button_check_vehicle_in(self):
        if self.env.context.get('request_id'):
            request = self.env['vehicle.request.details'].browse(self.env.context.get('request_id'))
            request.write({'state': 'checkin','drive_in_by': self.drive_in_by,'driver_in_name': self.driver_in_name.id, 'employee_in_name': self.employee_in_name.id, 'check_in_date_time': self.check_in_date_time, 'return_fuel_reading': self.return_fuel_reading, 'return_mileage': self.return_mileage})


            #vehicle Check-In_sms_notification_starts_here
            method_name = 'send_sms'
            sendSMS = getattr(SMS,method_name)

            drive_out_by="drive_out_by"
            dib = request[drive_out_by]

            field="driver_assign_number"
            driver_assign_number=request[field]

            field="emp_request_number"
            emp_request_number=request[field]

            field="transport_assign_number"
            transport_assign_number=request[field]

            field="start_mileage"
            start_mileage=request[field]
            if start_mileage>self.return_mileage:
                    raise Warning('End Mileage must be greater than Start Mileage: '+ start_mileage)


            vehicle_type="license_plate"
            vehicle_in=request[vehicle_type].plate_number

            destination="destination"
            destin=request[destination] 

            time_in = str(self.check_in_date_time) 

            
            if dib=="dr":
                sendSMS([driver_assign_number],"You have been CHECKED-IN successfully. Welcome Back...")
                sendSMS([transport_assign_number],"Vehicle "+vehicle_in+" From "+destin+" is CHECKED-IN at "+time_in)
            else:
                sendSMS([emp_request_number],"You have been CHECKED-IN successfully. Welcome Back...")
                sendSMS([transport_assign_number],"Vehicle "+vehicle_in+" From "+destin+" is CHECKED-IN at "+time_in)
   



class RefuseRequest(models.Model):
    _name = "refuse.request"

    refuse_opinion = fields.Selection([('DISAGREE', 'DISAGREE')],default='DISAGREE', string='Opinion', readonly=True)
    refuse_date =fields.Datetime(string="Refuse Date", default=lambda *a: datetime.now(),readonly=True) 
    refuse_reason =fields.Text(string="Comment", required=True)


    @api.multi
    def button_return(self):
        if self.env.context.get('request_id'):
            request = self.env['vehicle.request.details'].browse(self.env.context.get('request_id'))
            request.write({'state': 'ret', 'refuse_opinion': self.refuse_opinion,'refuse_date': self.refuse_date, 'refuse_reason': self.refuse_reason})


            #vehicle returned request_sms_notification_starts_here
            method_name = 'send_sms'
            sendSMS = getattr(SMS,method_name)

            field="emp_request_number"
            emp_request_number=request[field]
            
            sendSMS([emp_request_number],self.refuse_reason) 



class SMS(models.Model):
    _name = "sms"

    @api.multi
    def send_sms(employee_numbers, message_content):
        #_logger.info("Ping -c 1 192.168.15.21")
        # ping = os.system("ping  192.168.15.21")
        #_logger.info(ping)
        for recipient_number in employee_numbers:
            url="http://192.168.15.21:8091/CellcomAPIService"
            headers = {'content-type': 'application/soap+xml'}
            body ="\
            <s:Envelope xmlns:a='http://www.w3.org/2005/08/addressing' xmlns:s='http://www.w3.org/2003/05/soap-envelope'>\
              <s:Header>\
                <a:Action s:mustUnderstand='1'>http://tempuri.org/ISubscribers/SubscriberSendNotification</a:Action>\
                <a:MessageID>urn:uuid:3472a125-74f5-4914-865d-d1037d1dcbd8</a:MessageID>\
                <a:ReplyTo>\
                  <a:Address>http://www.w3.org/2005/08/addressing/anonymous</a:Address>\
                </a:ReplyTo>\
              </s:Header>\
              <s:Body>\
                <SubscriberSendNotification xmlns='http://tempuri.org/'>\
                  <c_subs_req xmlns:d4p1='http://schemas.datacontract.org/2004/07/CellcomAPILibrary' xmlns:i='http://www.w3.org/2001/XMLSchema-instance'>\
                    <d4p1:Client>wcf client tool</d4p1:Client>\
                    <d4p1:Password>h1$d/6Hf78(hg</d4p1:Password>\
                    <d4p1:UserName>HIS</d4p1:UserName>\
                    <d4p1:DestinationNumber>%s</d4p1:DestinationNumber>\
                    <d4p1:NotificationText>%s</d4p1:NotificationText>\
                    <d4p1:NotificationType>SMS</d4p1:NotificationType>\
                    <d4p1:OriginatingNumber>OLIB VRFMS</d4p1:OriginatingNumber>\
                  </c_subs_req>\
                </SubscriberSendNotification>\
              </s:Body>\
            </s:Envelope>\
            " %(recipient_number, message_content)
            response = requests.post(url,data=body,headers=headers)
            print(response.content)

            return response

        return False
