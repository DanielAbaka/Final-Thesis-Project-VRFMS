# -*- coding: utf-8 -*-
from . import vehicle_details
from . import vehicle_config