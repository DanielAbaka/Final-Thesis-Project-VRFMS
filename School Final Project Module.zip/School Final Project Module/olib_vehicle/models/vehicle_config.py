# -*- coding: utf-8 -*-

from odoo import api, fields, models, tools

# Vehicle Make Code Start Here

class OLIBVehicleDetailsMake(models.Model):
	_name ='vehicle.details.make'

	_rec_name = 'name_of_make'

	name_of_make = fields.Char('Make', required=True)
	image_of_make = fields.Binary('Logo', attachement=True)


# Vehicle Make Code End Here


# Vehicle Model Code Start Here

class OLIBVehicleDetailsModel(models.Model):
	_name ='vehicle.details.model'

	_rec_name = 'name_of_model'

	name_of_model = fields.Char('Model', required=True)
	image_of_brand = fields.Binary(related='brand.image_of_make', readonly=True)
	brand = fields.Many2one('vehicle.details.make', required=True )



# Vehicle Model Code End Here

# Vehicle Tags Code Start Here

class OLIBVehicleDetailsTags(models.Model):
	_name ='vehicle.details.tags'

	_rec_name = 'name_of_tag'

	name_of_tag = fields.Char(required=True, translate=True)
	color = fields.Integer('Color Index', default=10)

	_sql_constraints = [('name_uniq', 'name_uniq (name_of_tag)', "Tag name already exists!")]


# Vehicle Tags Code End Here


# Vehicle Type Code Start Here

class OLIBVehicleDetailsType(models.Model):
	_name ='vehicle.details.types'

	_rec_name = 'name_of_type'

	name_of_type = fields.Char(required=True, translate=True)

	_sql_constraints = [('name_uniq', 'name_uniq (name_of_type)', "Type name already exists!")]


# Vehicle Type Code End Here