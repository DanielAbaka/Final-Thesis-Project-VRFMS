# -*- coding: utf-8 -*-

from odoo import api, fields, models, tools


class OLIBVehicleDetails(models.Model):
	_name ='vehicle.details'

	_rec_name = 'plate_number'


	image = fields.Binary(related='model_name.image_of_brand', string="Image", readonly=True)
	plate_number = fields.Char(string='Licence Plate', required=True)
	model_name = fields.Many2one('vehicle.details.model',string='Model', required=True)
	make_name = fields.Many2one(related='model_name.brand', string='Make', readonly=True)
	tags_name = fields.Many2one('vehicle.details.tags', string='Tags', required=True)
	driver_assigned = fields.Many2one('driver.details', string='Driver Assigned')
	registration_start_date = fields.Date(string='Reg Start Date', required=True)
	registration_end_date = fields.Date(string='Reg End Date', required=True)
	enginee_number = fields.Char(string='Enginee Number')
	model_year = fields.Char(string='Model Year')
	vehicles_type = fields.Many2one('vehicle.details.types', string='Type', required=True)
	seats = fields.Integer(string='Seating Capacity', required=True)
	doors = fields.Integer(string='Doors', required=True)
	color = fields.Char(string='Color', required=True)
	level = fields.Selection([('excom','EXCOM CARS'), ('poolofcars','POOL OF CARS'), ('reserved','RESERVED CARS')], 'Level',help='Level of vehicle', required=True)
	tracking = fields.Selection([('activated','Activated'), ('notactivated', 'Not Activated')], 'Tracking', required=True)
	transmission = fields.Selection([('manual','Manual'), ('automatic', 'Automatic')], 'Transmission', required=True)
	fuel_type = fields.Selection([('gasoline','Gasoline'), ('diesel','Diesel')], 'Fuel Type',help='Fuel Used by vehicle', required=True)
	